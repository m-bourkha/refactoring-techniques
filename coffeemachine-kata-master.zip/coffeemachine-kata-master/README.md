# Coffeemachine Kata

This is a simple legacy coffeemachine commandline application.
It uses only statics and is strongly coupled to the System global.
You can use it to practice adding characterization tests and refactoring.

This [Youtube Episode](https://www.youtube.com/watch?v=qHGc373a998) demonstrates adding tests to the code.

The code was found on [stackexchange](https://codereview.stackexchange.com/questions/83135/designing-a-coffee-machine)
