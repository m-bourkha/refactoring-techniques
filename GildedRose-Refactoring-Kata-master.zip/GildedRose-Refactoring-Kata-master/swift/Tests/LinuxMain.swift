@testable import GildedRoseTestSuit

import XCTest

XCTMain([
     testCase(GildedRoseTests.allTests),
])
