You will need the following programs:

  - GNU make (on Debian-like systems do 'apt-get install make')
  - gcc with Ada enabled ('apt-get install gnat')
  - the ahven unit-test framework ('apt-get install libahven5-dev')

'make test' runs your tests once.

