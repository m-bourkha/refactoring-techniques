rm GildedRose
rm GildedRose.o
make
./GildedRose