#define APPROVALS_GOOGLETEST
#include "ApprovalTests.v.2.0.0.hpp"
