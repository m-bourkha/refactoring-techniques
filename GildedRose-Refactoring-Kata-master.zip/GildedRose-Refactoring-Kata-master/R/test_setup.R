# A little helper script to get the testing infrastructure started

# install.packages("RUnit")
require(RUnit)

# execute single test file
runTestFile("runit_gilded_rose.R")
