# Erlang

## Prerequisites

- Erlang/OTP 20 or later

## Running Tests

```
./rebar3 eunit
```
