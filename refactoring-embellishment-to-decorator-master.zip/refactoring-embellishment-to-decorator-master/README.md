# Refactor Embellishment to Decorator
This is a simple refactoring kata to practice the moving of an embellishment to a decorator.