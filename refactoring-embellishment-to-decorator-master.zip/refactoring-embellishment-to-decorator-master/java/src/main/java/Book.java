public class Book {
    public final String title;
    public final String author;

    public Book(String title, String author) {
        this.title = title;
        this.author = author;
    }
}
